-- 创建数据库
create database if not exists my default character set utf8mb4 collate utf8mb4_unicode_ci;
-- 创建my数据库
-- 使用字符集utf8mb4--用于存储 Unicode 字符集的数据
-- 排序规则设置为utf8mb4_unicode_ci，指定如何对字符进行排序和比较
-- 使用刚刚创建的这个my 数据库
use my;
-- 创建一个用户登录信息表
create table if not exists `userid`(
    `id` int(12) not null auto_increment comment '用户id',
    `available` tinyint(1) NOT NULL DEFAULT '0'comment '使用状态0在用1注销',
    `numberofuses` int NOT NULL DEFAULT '1' COMMENT '手机号码注册次数',
    `phone` varchar(11) default '0' comment '手机号',
    `userweixin` varchar(100) default '0' comment '用户微信账号',
    `userpassword` varchar(30) default '0' comment '密码',
    `addtime` datetime not null default CURRENT_TIMESTAMP comment '创建时间',
    `updatetime` datetime not null default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP comment '最后更新时间',
    `idcard` varchar(18) default null comment '用户身份证号码',
    `idname` varchar(18) default '0' comment '用户真实姓名',
    `sex` int(2) default 0 comment '用户真实性别',
    primary key (id)
) engine=InnoDB auto_increment=1 default charset =utf8mb4 encryption='N';
-- 设置`id`字段为主键 在最后一行中设置这个表的主键
-- engine=InnoDB 指定使用InnoDB模型
-- encryption ='n' 表示不加密 需要显式指定不加密选项
-- auto_increment=0 指定id的auto_increment 自增是从0开始
-- 创建学生表--每个学生都对应老师
create table if not exists `usersetting`(
    `idsetting` int(12) not null comment '用户个人信息id',
    `idimage` varchar(100) default '0' not null comment '关联主键用户id',
    `idname` varchar(20) default '0' not null comment '用户名字',
    `idcard` varchar(20) default '0' not null comment '实名状态',
    `sex` varchar(3) default '0' not null comment '性别',
    `region` varchar(20) default '0' not null comment '用户选择显示所在地区',
    `newmessage` int(3) default '0' not null comment '新消息提示',
    `userstatus` int(3) default 0 not null comment '个性状态',
    `addtime` datetime not null default CURRENT_TIMESTAMP comment '创建时间',
    `updatetime` datetime not null default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP comment '最后更新时间',
    `loginregin` varchar(20) default '0' not null comment '登录状态',
    primary key (`idsetting`),
    key `id` (`idsetting`),
    constraint `userstting_ibfk_1` foreign key (`idsetting`) references `userid`(`id`)
)engine=InnoDB auto_increment=1 default charset =utf8mb4 encryption='N';
-- idstting为主键，
-- #设置`id_s`字段为主键  在设置字段的行中设置主键  mysql默认把id字段设置为主键，这里的是`id_s` 所以需要在行内设置
-- #id字段为关联老师表的id，设置关联外键字段 关联teacher表中的id字段
-- #设置外键，参照另外一个表的主键
-- # engine=InnoDB 指定使用InnoDB模型
-- # encryption ='n' 表示不加密 需要显式指定不加密选项
-- # auto_increment=0 指定id的auto_increment 自增是从0开始

-- 创建token表--每个token都有对应的userid表种的id
create table if not exists `userstoken`(
    `id` int(12) not null comment '用户id',
    `idtoken` varchar(100) default '0' not null comment '用户的token',
    `ipregion` varchar(20) default '0' not null comment '用户选择显示所在地区',
    `addtime` datetime not null default CURRENT_TIMESTAMP comment '创建时间',
    `updatetime` datetime not null default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP comment '最后更新时间',
    `loginregin` varchar(20) default '0' not null comment '登录状态',
    primary key (`id`),
    key `id` (`id`),
    constraint `userstoken_ibfk_1` foreign key (`id`) references `userid`(`id`)
)engine=InnoDB auto_increment=1 default charset =utf8mb4 encryption='N';
-- id为主键，
-- #设置`id`字段为主键  在设置字段的行中设置主键  mysql默认把id字段设置为主键，
-- #id字段为关联userid表的id，设置关联外键字段 关联userid表中的id字段
-- #设置外键，参照另外一个表的主键
-- # engine=InnoDB 指定使用InnoDB模型
-- # encryption ='n' 表示不加密 需要显式指定不加密选项
-- # auto_increment=0 指定id的auto_increment 自增是从0开始