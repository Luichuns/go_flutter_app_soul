from django.db import models

from django.utils import timezone

class Post(models.Model):
    title = models.CharField(max_length=250)
    slug = models.SlugField(max_length=250)
    body = models.TextField()
    # 使用timezone方式来获取时间区域的当前时间
    publish = models.DateTimeField(default=timezone.now)
    # 标准库中获取当前区域的时间
    # DateTimeFieldDATETIMEtimezone.nowtimezonetimezone.nowdatetime.now

    # 当创建这条数据时，自动添加时间  是
    created = models.DateTimeField(auto_now_add=True)
    # 每次更新 都修改为当前时间  是  通过使用 ，保存对象时日期将自动更新。
    updated = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.title