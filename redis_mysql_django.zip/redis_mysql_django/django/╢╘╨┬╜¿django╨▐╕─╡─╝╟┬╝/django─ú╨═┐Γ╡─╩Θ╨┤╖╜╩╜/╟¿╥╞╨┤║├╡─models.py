# 指定执行某个包，这样不会把所有的都重新写一遍，因为有些不需要django来生成
# 什么不用django来生成？已经在mysql中写好的就不需要生成迁移文件包

# 需要在INSTALLED_APPS = []中添加需要的迁移应用
# 迁移INSTALLED_APPS = []应用中对应的应用里面的models.py中写好的模型
python manage.py makemigrations blog
# 会制作出0001_initial.pymigrationsblogPostpublish文件
# 此迁移包含用于为模型创建数据库表和为字段定义数据库索引的 SQL 语句。
# 写了写入mysql中的命令行


# 执行写好的命令行
python manage.py sqlmigrate blog 0001
# 指定执行这个迁移表中的命令行
# 为什么要指定迁移包？因为不想执行其它的迁移包


# 生成所有的迁移包，生成想要对数据库操作的sql命令包
# python manage.py makemigrations
# 执行所有写好的迁移包中的sql数据行
# python manage.py sqlmigrate