from django.db import models

from django.utils import timezone
class Post(models.Model):
    title = models.CharField(max_length=250)
    slug = models.SlugField(max_length=250)
    body = models.TextField()
    publish = models.DateTimeField(default=timezone.now)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        # 当查询中未指定顺序时，从数据库获取对象时，将应用默认顺序
        # 使用什么字段的正序还是倒叙作为排序
        ordering = ['-publish']
    def __str__(self):
        return self.title