from django.db import models

from django.utils import timezone
class Post(models.Model):
    # https://docs.djangoproject.com/zh-hans/4.1/ref/models/fields/
    # 状态字段，在admin中显示状态的选择
    # 要写成一个类
    # 里面写出的值作为枚举
    # 枚举的键值对
    # Draft为值，人类看的懂的值
    class Status(models.TextChoices):
        DRAFT = 'DF', 'Draft'
        PUBLISHED = 'PB', 'Published'
    title = models.CharField(max_length=250)
    slug = models.SlugField(max_length=250)
    body = models.TextField()
    publish = models.DateTimeField(default=timezone.now)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    # 状态字段位置
    status = models.CharField(max_length=2,choices=Status.choices,default=Status.DRAFT)
    class Meta:
        ordering = ['-publish']
        indexes = [models.Index(fields=['-publish']),]
    def __str__(self):
        return self.title
    
# 添加状态字段
# 博客的一个常见功能是将帖子另存为草稿,直到准备好发布.
# 我们将向模型添加一个字段,该字段将使我们能够管理博客文章的状态.
# 我们将对帖子使用草稿和已发布状态.status

# 编辑应用程序的文件,使其如下所示。新行以粗体突出显示:models.pyblog