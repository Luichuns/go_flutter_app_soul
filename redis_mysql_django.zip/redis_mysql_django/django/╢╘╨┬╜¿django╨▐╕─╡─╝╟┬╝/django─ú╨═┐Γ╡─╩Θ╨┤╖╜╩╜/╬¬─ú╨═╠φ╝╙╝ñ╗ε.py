# 我们需要激活项目中的应用程序，以便 Django 跟踪应用程序并能够为其模型创建数据库表。blog

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    # 
    # 
    # 添加blog应用
    'blog.apps.BlogConfig',
]
# 该类是应用程序配置。现在 Django 知道应用程序对于这个项目是活跃的，并且能够加载应用程序模型。BlogConfig
# 【问题】  为什么是添加'blog.apps.BlogConfig' 而不是添加'blog'