from django.db import models

from django.utils import timezone
class Post(models.Model):
    title = models.CharField(max_length=250)
    slug = models.SlugField(max_length=250)
    body = models.TextField()
    publish = models.DateTimeField(default=timezone.now)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    class Meta:
        ordering = ['-publish']
        # 为字段定义一个数据库索引。这将提高按此字段筛选或排序结果的查询的性能。
        # 我们希望许多查询利用此索引，因为默认情况下我们使用该字段对结果进行排序。
        # MySQL 不支持索引排序。如果对数据库使用 MySQL，则会创建一个降序索引作为普通索引。
        indexes = [
            models.Index(fields=['-publish']),
        ]
    def __str__(self):
        return self.title