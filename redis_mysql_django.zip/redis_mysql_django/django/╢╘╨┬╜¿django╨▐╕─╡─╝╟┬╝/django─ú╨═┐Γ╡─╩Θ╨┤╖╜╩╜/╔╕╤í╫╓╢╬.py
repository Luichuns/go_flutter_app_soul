# newapp/admin.py文件
from django.contrib import admin

from .models import Post
@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    # 显示的字段
    list_display = ['title', 'slug', 'author', 'publish', 'status']
    # 可以进行筛选的字段，在右方的筛选列表中
    list_filter = ['status', 'created', 'publish', 'author']
    # 可以搜索的字段，在左上方的搜索功能中
    search_fields = ['title', 'body']
    prepopulated_fields = {'slug': ('title',)}
    raw_id_fields = ['author']
    date_hierarchy = 'publish'
    ordering = ['status', 'publish']