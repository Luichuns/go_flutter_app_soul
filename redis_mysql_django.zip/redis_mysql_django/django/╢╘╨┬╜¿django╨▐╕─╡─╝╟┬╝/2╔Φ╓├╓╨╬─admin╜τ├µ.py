# 2设置admin管理界面的语言
# 英文
# LANGUAGE_CODE = 'en-us'
# 中文设置以2种
# 简体中文--django/conf/zh_Hans/LC_MESSAGES/django.po
LANGUAGE_CODE = 'zh-Hans'
# 繁体中文--django/conf/zh_Hant/LC_MESSAGES/django.po
# LANGUAGE_CODE = 'zh-Hant'
# 日文设置1种
# LANGUAGE_CODE = 'ja'