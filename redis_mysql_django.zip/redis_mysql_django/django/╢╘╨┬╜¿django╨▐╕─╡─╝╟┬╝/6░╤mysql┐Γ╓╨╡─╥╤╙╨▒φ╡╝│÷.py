
# 首要条件
# 安装插件
# PyMySQL==1.0.3

# 文件设置导入包
# app/__init__.py文件中添加
# 代码
import pymysql
pymysql.install_as_MySQLdb()
# 容器中运行django管理器的导出命令
# python manage.py inspectdb > models.py
# 这个会把mysql中my库中的表导出到app/models.py文件中
# 以django models.py模型方式 在models.py文件中列出 my库中的所有表
# 导出后注释掉app/__init__.py文件中添加的代码
# 接下来仅需要把这里面的表 用到对应的应用包中 如newapp/models.py文件中


# 在app/newapp/models.py文件中 
# 把类中的managed设置为True
# managed = False

# 以下是newapp/models.py中的代码
# ---------------------

