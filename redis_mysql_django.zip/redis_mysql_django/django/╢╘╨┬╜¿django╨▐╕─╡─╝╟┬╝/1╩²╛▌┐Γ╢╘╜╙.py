# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.sqlite3',
#         'NAME': BASE_DIR / 'db.sqlite3',
#     }
# }

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",
        "USER": "root",
        "PASSWORD": "root1234",
        # 通过宿主机终端输入ipconfig 来获取这个网组的ip
        "HOST": "172.23.32.1",
        "PORT": "3306",
        "NAME": "my",#数据库名字
        # "OPTION":{'charset': 'utf8mb4'},
    }
}