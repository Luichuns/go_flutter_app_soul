# newapp/admin.py文件中
from django.contrib import admin
# 导入本个应用中的models的模型
from .models import Userid,Usersetting,Userstoken

# Register your models here.

# 注册模型列表,管理界面可以显示
@admin.register(Userid)
class UseridAdmin(admin.ModelAdmin):
    # 列出在admin管理界面中想要显示的字段
    # list_display=('available','get_available','total_available','numberofuses','phone','userweixin','userpassword','addtime','updatetime','idcard','idname','sex')
    list_display=('available','numberofuses','phone','userweixin','userpassword','addtime','updatetime','idcard','idname','sex')
    # def get_available(self,obj):
    #     return ''
    # get_available.short_description = '空白列'
    # def total_available(self,obj):
    #     return obj.available + obj.sex
    # total_available.short_description = '计算列'

# 使用装饰器方式，或者用注册方式，二选一即可
# @admin.register(Userid)
# admin.site.register(Userid,UseridAdmin)

@admin.register(Usersetting)
class UsersettingAdmin(admin.ModelAdmin):
    list_display=('idsetting','idimage','idname','idcard','sex','region','newmessage','userstatus','addtime','updatetime','loginregin')

# admin.site.register(Usersetting,UsersettingAdmin)

@admin.register(Userstoken)
class UserstokenAdmin(admin.ModelAdmin):
    list_display=('id','idtoken','ipregion','addtime','updatetime','loginregin')

# admin.site.register(Userstoken,UserstokenAdmin)