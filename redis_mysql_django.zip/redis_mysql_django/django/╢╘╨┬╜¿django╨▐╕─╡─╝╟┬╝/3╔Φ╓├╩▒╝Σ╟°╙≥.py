# 设置admin的时区
TIME_ZONE = 'Asia/Shanghai'