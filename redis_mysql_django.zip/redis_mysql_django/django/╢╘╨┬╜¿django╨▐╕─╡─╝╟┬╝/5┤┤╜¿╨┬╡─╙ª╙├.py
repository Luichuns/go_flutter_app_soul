# 执行命令
python manage.py startapp newapp

# 创建后请添加到 settings.py文件中的 INSTALLED_APPS 列表中

# 创建管理go项目数据库的链接应用
# python manage.py startapp goback
