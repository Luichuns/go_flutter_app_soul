allone=Post.objects.all()
# 这是一个查询QuerySet方法

# allone为一个对象，查询某个表的所有对象
# Post是某张表，表明为Post
# .objects 是获取这个表中的对象
# .all()  是获取所有对象
allone=Post.objects.filter(publish__year=2022)
# publish是时间字段
# 两个下划线，使用两个下划线构建具有字段查找方法的查询，但相同的表示法也用于访问相关模型的字段
# 指定punlish中的年份字符 使用 publish__year 来表示，并指定2022年
# 查询Post表中publish字段中year年份为2022的数据

# 查询多个字段
Post.objects.filter(publish__year=2022, author__username='admin')
# 查询2022年的
# 并且作者名字为 admin
# author是外键，也就是这个表执行另外一个表的主键


# 使用管理器的方法从您的方法中排除某些结果
# 查询1个字段 年份为2022年的，但是当title标题是“Why”开头的字段都不要
Post.objects.filter(publish__year=2022).exclude(title__startswith='Why')

# 使用管理器的方法按不同字段对结果进行排序。
# 以"title"字段升序为排序
Post.objects.filter(publish__year=2022).exclude(title__startswith='Why').order_by('title')
# 以"title"字段降序为排序
Post.objects.filter(publish__year=2022).exclude(title__startswith='Why').order_by('-title')


# 这是一个查询QuerySet方法
# 对QuerySet的查询集合何以使用以下方法
# 第一次迭代它们时
# 例如，当您切片它们时，Post.objects.all()[:3]
# 当你腌制或缓存它们时
# 当您致电或致电他们时repr()len()
# 当您显式调用它们时list()
# 在语句中测试它们时，例如、、或bool()orandif