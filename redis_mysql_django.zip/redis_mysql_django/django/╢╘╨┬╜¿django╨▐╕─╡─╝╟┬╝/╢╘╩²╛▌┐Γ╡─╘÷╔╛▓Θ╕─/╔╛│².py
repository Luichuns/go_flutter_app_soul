# 获取Post表中 字段id=1的数据
# 这是一个查询QuerySet方法
post = Post.objects.get(id=1)

# 把获取到的数据进行删除
post.delete()
