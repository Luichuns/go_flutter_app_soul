from django.http import HttpResponse

def index(request):
    print("hello")
    ak()
    return HttpResponse("hello")

def ak():
    print("asdasds")