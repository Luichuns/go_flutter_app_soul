from pathlib import Path

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# 安全码，创建项目时自动生成，当需要上线时，请另外使用随机生成，别面和这里的一样
SECRET_KEY = 'django-insecure-2@v^m-(tt8!9e@gb8rfs2i4%bt1xw&5^$uv+69+6*pfo+&c630'

DEBUG = True
# DEBUG = False
# debug_toolbar 调试插件的使用需修改为True

ALLOWED_HOSTS = ["*",]

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    # debug_toolbar 修改1
    # 'debug_toolbar',
    'debug_toolbar',
    'newapp',
]

MIDDLEWARE = [
    # debug_toolbar 修改2
    # 'debug_toolbar.middleware.DebugToolbarMiddleware',
    # 'debug_toolbar.middleware.DebugToolbarMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'app.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'app.wsgi.application'


# 1
# 设置连接mysql数据库，而不是默认的sqlite3数据库
# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.sqlite3',
#         'NAME': BASE_DIR / 'db.sqlite3',
#     }
# }

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",
        "USER": "root",
        "PASSWORD": "root1234",
        "HOST": "172.23.32.1",
        "PORT": "3306",
        "NAME": "my",#数据库名字
        # "OPTION":{'charset': 'utf8mb4'},
    }
}


AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# 2设置admin管理界面的语言
# 英文
# LANGUAGE_CODE = 'en-us'
# 中文设置以2种
# 简体中文--django/conf/zh_Hans/LC_MESSAGES/django.po
LANGUAGE_CODE = 'zh-Hans'
# 繁体中文--django/conf/zh_Hant/LC_MESSAGES/django.po
# LANGUAGE_CODE = 'zh-Hant'
# 日文设置1种
# LANGUAGE_CODE = 'ja'

# 设置时区为上海时区
TIME_ZONE = 'Asia/Shanghai'
USE_I18N = True
USE_TZ = True
STATIC_URL = 'static/'
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# debug_toolbar 修改3
# INTERNAL_IPS=['127.0.0.1',]
INTERNAL_IPS=['127.0.0.1',]

# debug_toolbar 修改4
# if DEBUG:
#     import socket  # only if you haven't already imported this
#     hostname, _, ips = socket.gethostbyname_ex(socket.gethostname())
#     INTERNAL_IPS = [ip[: ip.rfind(".")] + ".1" for ip in ips] + ["127.0.0.1", "10.0.2.2"]
if DEBUG:
    import socket  # only if you haven't already imported this
    hostname, _, ips = socket.gethostbyname_ex(socket.gethostname())
    INTERNAL_IPS = [ip[: ip.rfind(".")] + ".1" for ip in ips] + ["127.0.0.1", "10.0.2.2"]
    # 把调试时的服务器公网的ip写进去
    # INTERNAL_IPS = [ip[: ip.rfind(".")] + ".1" for ip in ips] + ["0.0.0.0", "10.0.2.2"]