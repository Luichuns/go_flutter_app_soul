
from django.contrib import admin
from django.urls import path
# debug_toolbar 修改5
# from django.urls import include
from django.urls import include

urlpatterns = [
    path('admin/', admin.site.urls),
    # 添加主页访问显示的视图函数
    # path('', index),
    path('', index),
    # debug_toolbar 修改6
    # 二选一
    # path('__debug__/', include('debug_toolbar.urls')),
]

# debug_toolbar 修改6
# 二选一
# from app.settings import DEBUG
# if DEBUG:
#     import debug_toolbar
#     urlpatterns = [path('__debug__/', include(debug_toolbar.urls)),] + urlpatterns

from app.settings import DEBUG
if DEBUG:
    import debug_toolbar
    urlpatterns = [path('__debug__/', include(debug_toolbar.urls)),] + urlpatterns