from django.db import models
# 当需要使用django来自动生成时间的字段数据时，需要添加timezone这个函数
# from django.utils import timezone
# 我这里使用的是mysql管理系统来自动生成写入时间字段，所以不使用django里面生成时间字段方式写入数据

# Create your models here.
class Userid(models.Model):
    available = models.IntegerField()
    numberofuses = models.IntegerField()
    phone = models.CharField(max_length=11, blank=True, null=True)
    userweixin = models.CharField(max_length=100, blank=True, null=True)
    userpassword = models.CharField(max_length=30, blank=True, null=True)
    addtime = models.DateTimeField()
    updatetime = models.DateTimeField()
    idcard = models.CharField(max_length=18, blank=True, null=True)
    idname = models.CharField(max_length=18, blank=True, null=True)
    sex = models.IntegerField(blank=True, null=True)

    def __str__(self):
        # 当添加/删除了一条数据后，在删除成功后，显示被删除的数据中的N个数据
        # 显示1个字段
        return self.phone
        #  显示2个字段
        # return str(self.phone) +str(self.sex)

    class Meta:
        managed = True
        # 在mysql库中的表名 userid
        db_table = 'userid'
        # 使django admin 后台管理界面显示这个表名为中文
        # verbose_name = '用户表'
        # verbose_name_plural = '用户表'
        # 选择在通过django方式查询这个表后，希望显示数据的排列顺序
        # 希望显示的是添加时间的倒叙
        # ordering=['-addtime']


class Usersetting(models.Model):
    idsetting = models.OneToOneField(Userid, models.DO_NOTHING, db_column='idsetting', primary_key=True)
    idimage = models.CharField(max_length=100)
    idname = models.CharField(max_length=20)
    idcard = models.CharField(max_length=20)
    sex = models.CharField(max_length=3)
    region = models.CharField(max_length=20)
    newmessage = models.IntegerField()
    userstatus = models.IntegerField()
    addtime = models.DateTimeField()
    updatetime = models.DateTimeField()
    loginregin = models.CharField(max_length=20)

    class Meta:
        managed = True
        # 在mysql库中的表名 usersetting
        db_table = 'usersetting'
        # 使django admin 后台管理界面显示这个表名为中文
        # verbose_name = '用户设置表'
        # verbose_name_plural = '用户设置表'


class Userstoken(models.Model):
    id = models.OneToOneField(Userid, models.DO_NOTHING, db_column='id', primary_key=True)
    idtoken = models.CharField(max_length=100)
    ipregion = models.CharField(max_length=20)
    addtime = models.DateTimeField()
    updatetime = models.DateTimeField()
    loginregin = models.CharField(max_length=20)

    class Meta:
        managed = True
        # 在mysql库中的表名 userstoken
        db_table = 'userstoken'
        # 使django admin 后台管理界面显示这个表名为中文
        # verbose_name = '用户token加密表'
        # verbose_name_plural = '用户token加密表'