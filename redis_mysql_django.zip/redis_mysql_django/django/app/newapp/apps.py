from django.apps import AppConfig


class NewappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'newapp'
    # 使django admin 后台管理界面显示这个应用组名为中文
    verbose_name = '用户数据应用'

