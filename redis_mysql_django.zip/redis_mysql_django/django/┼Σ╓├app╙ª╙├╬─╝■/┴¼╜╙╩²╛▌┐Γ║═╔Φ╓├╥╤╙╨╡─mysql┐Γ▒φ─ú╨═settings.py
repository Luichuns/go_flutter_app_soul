# 1
# 设置连接mysql数据库，而不是默认的sqlite3数据库
# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.sqlite3',
#         'NAME': BASE_DIR / 'db.sqlite3',
#     }
# }

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.mysql",
        "USER": "root",
        "PASSWORD": "root1234",
        "HOST": "172.23.32.1",
        "PORT": "3306",
        "NAME": "my",#数据库名字
        # "OPTION":{'charset': 'utf8mb4'},
    }
}

# 2设置admin管理界面的语言
# 英文
# LANGUAGE_CODE = 'en-us'
# 中文设置以2种
# 简体中文--django/conf/zh_Hans/LC_MESSAGES/django.po
LANGUAGE_CODE = 'zh-Hans'
# 繁体中文--django/conf/zh_Hant/LC_MESSAGES/django.po
# LANGUAGE_CODE = 'zh-Hant'
# 日文设置1种
# LANGUAGE_CODE = 'ja'

# 设置admin的时区
TIME_ZONE = 'Asia/Shanghai'
USE_TZ = True


# 数据库连接的IP设置为        "HOST": "172.23.32.1",
# 在宿主机中查找这个ip,:ipconfig
# 1
# 设置后数据库 同步  迁移
# python manage.py migrate
# python manage.py makemigrations
# 创建管理员
# python manage.py createsuperuser
# 运行测试
# python manage.py runserver 0.0.0.0:8080
# 请到主机http://127.0.0.1:8080/端口查看
# 创建新的应用newapp
# python manage.py startapp newapp
# 导出已有的my库中的表模型到app/models.py文件中，用于给新应用中的表定义模型
# --该文件位置是在manage.py下边----等到把需要的内容复制到要使用的文件夹之后，刚刚自动生成的models.py已经没有用了，就可以删除了

# 
# 安装插件
# PyMySQL==1.0.3
# 文件设置导入包
# app/__init__.py文件中添加
# 代码
# import pymysql
# pymysql.install_as_MySQLdb()
# 容器中运行django管理器的导出命令
# python manage.py inspectdb > models.py
# 这个会把mysql中my库中的表导出到app/models.py文件中
# 以django models.py模型方式 在models.py文件中列出 my库中的所有表
# 接下来仅需要把这里面的表 用到对应的应用包中
# 导出后注释掉app/__init__.py文件中添加的代码

# 在newapp/models.py文件中 把        类中的managed设置为True
# managed = False

# 添加这个newapp应用到django安装的应用apps列表中
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'newapp',
]

# 再次执行数据库同步
# python manage.py migrate
# 不要执行迁移# python manage.py makemigrations
# 迁移会报错误


# 在admin.py文件中添加管理列表
# -----------------------
# from django.contrib import admin
# # 导入本个应用中的models的模型
# from .models import Userid,Usersetting,Userstoken

# # Register your models here.

# # 注册模型列表,管理界面可以显示
# @admin.register()
# class Userid(admin.ModelAdmin):
#     list_display=('available','numberofuses','phone','userweixin','userpassword','addtime','updatetime','idcard','idname','sex',)

# @admin.register()
# class Usersetting(admin.ModelAdmin):
#     list_display=('idsetting','idimage','idname','idcard','sex','region','newmessage','userstatus','addtime','updatetime','loginregin',)

# @admin.register()
# class Userstoken(admin.ModelAdmin):
#     list_display=('id','idtoken','ipregion','addtime','updatetime','loginregin')

# -----------------------


# 设置newapp/app.py文件中的代码
# class NewappConfig(AppConfig):
#     default_auto_field = 'django.db.models.BigAutoField'
#     name = 'newapp'
#     verbose_name = '文章类'